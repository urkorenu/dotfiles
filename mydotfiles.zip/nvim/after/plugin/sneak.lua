require('sneak')
vim.keymap.set('n', 'f', '<Plug>Sneak_f', {})
vim.keymap.set('n', 'F', '<Plug>Sneak_F', {})


