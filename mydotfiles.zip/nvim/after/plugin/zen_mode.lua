require('zen-mode')
vim.keymap.set('n', '<leader>z', '<cmd>ZenMode<cr>', {})
